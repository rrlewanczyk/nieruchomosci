<?php return array('dependencies' => array('react', 'wp-components', 'wp-hooks', 'wp-i18n', 'wp-primitives'), 'version' => 'c0be3a4401cfc2367357');
