<?php return array('dependencies' => array('react', 'react-dom'), 'version' => '0ae0043e9a45c65c9b53');
