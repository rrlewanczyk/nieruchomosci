<?php return array('dependencies' => array('react'), 'version' => 'fe22a5ff6b9fb885c698');
