<?php
/**
 * Pagination load more template
 */

?>
<div class="jet-filters-pagination__link">/% $value %/</div>